import axios from 'axios';
import { StatusBar } from 'expo-status-bar';
import React, { Component } from 'react';
import { StyleSheet, Text, View, Button, Animated, Pressable } from 'react-native';
    
export default class GameOver extends Component {

    _isMounted = false;

    constructor(props) {
        super(props);
        this.state = {
            question: ""
        }
        this.opacity = new Animated.Value(0);
    }

    componentDidMount() {
        this._isMounted = true;
        axios.get('https://sus-game.herokuapp.com/')
        .then((response) => {
            let data = response.data;
            let random = Math.floor(Math.random() * Object.keys(data['Questions']).length);
            let question = data['Questions'][String(random)];
            if(this._isMounted)
            {
                this.setState({question: question})
            }
        })
    }

    componentWillUnmount() {
        this._isMounted = false;
    }

    render() {
        return(
            <View style={styles.container}>
                <Text>{this.state.question}</Text>
                <Pressable style={styles.button}onPress={() => this.props.navigation.navigate("Recycling")}>
                    <Text style={{color: 'white', textAlign: 'center'}}>Start Over</Text>
                </Pressable>
            </View>
        )
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignContent: 'center'
    },
    button: {
        width: 100,
        backgroundColor: "#5E5DF0",
        padding: 10,
        color: 'white',
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: 30,
        borderRadius: 20
    }
})