import React from "react";
import { View, Text, StyleSheet } from "react-native";

const Floor = (props) => {
    const width = props.size[0];
    const height = props.size[1];
    const x = props.body.position.x - width / 2;
    const y = props.body.position.y - height / 2;
    const score = props.score;
    const level = props.level;
    
    return (
        <View 
            style={{
                position: "absolute",
                left: x,
                top: y,
                width: width,
                height: height,
                backgroundColor: '#6d3e2e'
            }}
        >
            <View style={styles.textContainer}>
                <Text style={styles.textStyle}>Level: {level}</Text>
                <Text style={styles.textStyle}>Score: {score}</Text>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    textStyle: {
        color: 'white',
        fontSize: 15,
        padding: 10
    },
    textContainer: {
        flexDirection: 'row',
        justifyContent: 'space-between'
    }
})

export { Floor };